#pragma once
void Print_Array(unsigned int array_[], const unsigned short size_of_array); 

void Prime_Nums(unsigned int array_[], const unsigned short N);